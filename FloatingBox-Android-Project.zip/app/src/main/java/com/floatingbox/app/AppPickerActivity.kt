package com.floatingbox.app

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class AppPickerActivity : Activity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "اختار التطبيق"
            textSize = 24f
            setPadding(0, 0, 0, 16)
        })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        for (app in apps) {
            val row = TextView(this).apply {
                text = "📱  ${pm.getApplicationLabel(app)}"
                textSize = 18f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 16, 12, 16)
                setOnClickListener {
                    val launch = pm.getLaunchIntentForPackage(app.packageName)
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launch)
                    }
                    finish()
                }
            }
            list.addView(row)
        }
        root.addView(ScrollView(this).apply { addView(list) })
        setContentView(root)
    }
}
