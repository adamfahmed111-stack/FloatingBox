package com.floatingbox.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "Floating Box"
            textSize = 28f
        })
        layout.addView(TextView(this).apply {
            text = "فقاعة عائمة تفتح قائمة التطبيقات المثبتة."
            textSize = 16f
            setPadding(0, 18, 0, 24)
        })
        val permission = Button(this).apply {
            text = "السماح بالظهور فوق التطبيقات"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startFloating()
                }
            }
        }
        layout.addView(permission)
        layout.addView(Button(this).apply {
            text = "تشغيل الفقاعة"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) startFloating()
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        layout.addView(TextView(this).apply {
            text = "\nمهم: أندرويد قد يفتح التطبيق المختار بملء الشاشة بدل نافذة صغيرة. هذا يعتمد على دعم الهاتف والنظام."
            textSize = 14f
        })
        setContentView(layout)
    }

    private fun startFloating() {
        startService(Intent(this, FloatingService::class.java))
        finish()
    }
}
